<?php
return [
    'es' => [
        'welcome' => 'Bienvenido',
        'user_info' => 'Tu Información',
        'username' => 'Usuario',
        'add_user' => 'Añadir Usuario',
        'name' => 'Nombre',
        'surname' => 'Apellido',
        'email' => 'Email',
        'registered_users' => 'Usuarios Registrados',
        'logout_section' => 'Cerrar sesión',  // Asegurarse de que las claves son consistentes
        'logout' => 'Cerrar sesión',  // Asegurarse de que las claves son consistentes
        'select_language' => 'Selecciona tu idioma',
        'user_list' => 'Ver Usuarios',
        'personal_info' => 'Mis Datos',
        'actions' => 'Acciones',
        'save' => 'Guardar',
        'delete' => 'Eliminar',
    ],
    'en' => [
        'welcome' => 'Welcome',
        'user_info' => 'Your Information',
        'username' => 'Username',
        'add_user' => 'Add User',
        'name' => 'Name',
        'surname' => 'Surname',
        'email' => 'Email',
        'registered_users' => 'Registered Users',
        'logout_section' => 'Log out',  // Corregido para coincidir con las otras traducciones
        'logout' => 'Log out',  // Corregido para coincidir con las otras traducciones
        'select_language' => 'Select your language',
        'user_list' => 'View Users',
        'personal_info' => 'My Data',
        'actions' => 'Actions',
        'save' => 'Save',
        'delete' => 'Delete',
    ],
    'fr' => [
        'welcome' => 'Bienvenue',
        'user_info' => 'Vos Informations',
        'username' => 'Utilisateur',
        'add_user' => 'Ajouter un Utilisateur',
        'name' => 'Nom',
        'surname' => 'Prénom',
        'email' => 'Email',
        'registered_users' => 'Utilisateurs Enregistrés',
        'logout_section' => 'Se déconnecter',  // Unificado para todas las traducciones
        'logout' => 'Se déconnecter',  // Unificado para todas las traducciones
        'select_language' => 'Sélectionnez votre langue',
        'user_list' => 'Voir les utilisateurs',
        'personal_info' => 'Mes Données',
        'actions' => 'Actions',
        'save' => 'Enregistrer',
        'delete' => 'Supprimer',
    ],
];
?>
