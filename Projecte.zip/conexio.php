<?php
$host = '192.168.116.103';
$db = 'projecte';
$user = 'admin';
$pass = 'Xokorro20';

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Error en la conexión: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");
?>
