<?php
session_start();
include 'conexio.php';

// Redirigir al usuario al login si no está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit();
}

// Manejo del cambio de idioma
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['idioma'])) {
    $_SESSION['language'] = $_POST['idioma']; // Guardar el idioma en la sesión
    session_write_close(); // Asegurar que los cambios en la sesión se guardan
    header("Location: home.php"); // Recargar la página
    exit();
}

// Establecer idioma desde la sesión o usar el idioma predeterminado
$idioma = $_SESSION['language'] ?? 'es'; // Idioma predeterminado

// Cargar las traducciones
$translations = include 'translations.php';
$trans = $translations[$idioma] ?? $translations['es'];

$is_admin = ($_SESSION['usuario'] === 'admin');

// Handle actions for add, edit, delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $username = $_POST['username'] ?? null;
    switch ($_POST['action']) {
        case 'add':
            $new_username = $_POST['new_username'];
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $email = $_POST['email'];
            $query = "INSERT INTO usuarios (username, nombre, apellido, email) VALUES ('$new_username', '$nombre', '$apellido', '$email')";
            mysqli_query($conn, $query);
            break;
        case 'edit':
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $email = $_POST['email'];
            $query = "UPDATE usuarios SET nombre = '$nombre', apellido = '$apellido', email = '$email' WHERE username = '$username'";
            mysqli_query($conn, $query);
            break;
        case 'delete':
            $query = "DELETE FROM usuarios WHERE username = '$username'";
            mysqli_query($conn, $query);
            break;
    }
    header("Location: home.php"); // Recargar la página
    exit();
}

?>

<!DOCTYPE html>
<html lang="<?php echo $idioma; ?>">

<head>
    <meta charset="UTF-8">
    <title><?php echo $trans['welcome']; ?></title>
    <link rel="stylesheet" href="practica.css">
</head>

<body>
    <h1 style="color: white;"><?php echo $trans['welcome']; ?>, <?php echo htmlspecialchars($_SESSION['nombre']); ?>!</h1>

    <!-- Selección de idioma -->
    <form method="post" class="language-form">
        <label for="idioma" style="color: white;"><?php echo $trans['select_language']; ?>:
            <select name="idioma" id="idioma" onchange="this.form.submit()">
                <option value="es" <?php echo ($idioma === 'es') ? 'selected' : ''; ?>>Español</option>
                <option value="en" <?php echo ($idioma === 'en') ? 'selected' : ''; ?>>English</option>
                <option value="fr" <?php echo ($idioma === 'fr') ? 'selected' : ''; ?>>Français</option>
            </select></label>
    </form>

    <!-- Botones de Menú -->
    <div class="menu">
        <button onclick="document.getElementById('personal_info').style.display='block';"><?php echo $trans['personal_info']; ?></button>
        <?php if ($is_admin): ?>
            <button onclick="document.getElementById('user_list').style.display='block';"><?php echo $trans['user_list']; ?></button>
        <?php endif; ?>
        <button onclick="document.getElementById('logout_section').style.display='block';"><?php echo $trans['logout_section']; ?></button>
    </div>

    <!-- Sección de Información Personal -->
    <div id="personal_info" style="display:none;">
        <h2><?php echo $trans['user_info']; ?></h2>
        <p><strong><?php echo $trans['username']; ?>:</strong> <?php echo htmlspecialchars($_SESSION['usuario']); ?></p>
        <p><strong><?php echo $trans['name']; ?>:</strong> <?php echo htmlspecialchars($_SESSION['nombre']); ?></p>
        <p><strong><?php echo $trans['surname']; ?>:</strong> <?php echo htmlspecialchars($_SESSION['apellido']); ?></p>
        <p><strong><?php echo $trans['email']; ?>:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
    </div>

    <?php if ($is_admin): ?>
        <!-- Sección de Lista de Usuarios para Admin -->
        <div id="user_list">
            <h2><?php echo $trans['registered_users']; ?></h2>

            <!-- Formulario para Añadir Usuario
        <form method="post">
            <input type="hidden" name="action" value="add">
            <input type="text" name="new_username" placeholder="<?php echo $trans['username']; ?>" required>
            <input type="text" name="nombre" placeholder="<?php echo $trans['name']; ?>" required>
            <input type="text" name="apellido" placeholder="<?php echo $trans['surname']; ?>" required>
            <input type="email" name="email" placeholder="<?php echo $trans['email']; ?>" required>
            <input type="submit" value="<?php echo $trans['add_user']; ?>">
        </form> -->

            <table border="1">
                <tr>
                    <th><?php echo $trans['username']; ?></th>
                    <th><?php echo $trans['name']; ?></th>
                    <th><?php echo $trans['surname']; ?></th>
                    <th><?php echo $trans['email']; ?></th>
                    <th><?php echo $trans['actions']; ?></th>
                </tr>
                <?php
                $query = "SELECT username, nombre, apellido, email FROM usuarios";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<form method='post'>";
                    echo "<input type='hidden' name='action' value='edit'>";
                    echo "<input type='hidden' name='username' value='" . htmlspecialchars($row['username']) . "'>";
                    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                    echo "<td><input type='text' name='nombre' value='" . htmlspecialchars($row['nombre']) . "' required></td>";
                    echo "<td><input type='text' name='apellido' value='" . htmlspecialchars($row['apellido']) . "' required></td>";
                    echo "<td><input type='email' name='email' value='" . htmlspecialchars($row['email']) . "' required></td>";
                    echo "<td>";
                    echo '<input type="submit" value="' . htmlspecialchars($trans['save']) . '">';
                    echo "</form>";
                    echo "<form method='post' style='display:inline;' onsubmit='return confirm(\"¿Seguro que desea eliminar este usuario?\");'>";
                    echo "<input type='hidden' name='action' value='delete'>";
                    echo "<input type='hidden' name='username' value='" . htmlspecialchars($row['username']) . "'>";
                    echo '<input type="submit" value="' . htmlspecialchars($trans['delete']) . '">';
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
                mysqli_free_result($result);
                ?>
            </table>
        </div>
    <?php endif; ?>

    <!-- Botón para cerrar sesión -->
    <div id="logout_section" style="display:none;">
        <form action="logout.php" method="post">
            <button type="submit" class="logout-button"><?php echo $trans['logout']; ?></button>
        </form>
    </div>

</body>

</html>



<style>
    * {
        color: black;
    }

    div.menu>button {
        color: black;
    }

    select#idioma {
        color: black;
    }

    th {
        color: black;
    }

    td {
        color: white;
    }

    body {
        display: grid;
        place-content: center;
        text-align: center;
        font-family: Arial, sans-serif;
        background-color: rgb(38, 129, 120);
    }

    div.panel {
        background-color: white;
        border-radius: 15px;
        padding: 15px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    .logout-button {
        background-color: #ff4d4d;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 20px;
    }

    .logout-button:hover {
        background-color: #ff3333;
    }

    table {
        margin: 15px auto;
        border-collapse: collapse;
        width: 80%;
    }

    th,
    td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }

    th {
        background-color: #f2f2f2;
    }

    .language-form {
        margin-bottom: 20px;
    }

    select {
        padding: 5px;
        font-size: 14px;
    }

    label {
        text-align: center;
    }
</style>